RAS (Remote Access) API header for Delphi
-----------------------------------------

Version 1.1

Converted to Delphi by Davide Moretti <dmoretti@iper.net>

Feel free to use this code, but, please let me know that you are using it...

History
-------

Version 1.0: Initial release
Version 1.01: Replaced library index number with names to make it run with
   Windows NT. Thanks to Thom Randolph <thom@halcyon.com> for reporting and
   fixing this.
Version 1.1: Added the Extended Ras API functions. These functions can 
   manipulate the entries directly. They are found on Windows NT 4.0 and
   can be used also on Windows 95 using a special library (RNAPH.DLL) that
   is available at http://www.microsoft.com/win32dev/apiext/rasapi.htm.
   Note that in the example code I used only two of them (lack of time) but
   there are more functions available.
   Thanks to Gideon le Grange <legrange@adept.co.za> for sending me the
   new API information and a Delphi translation of them. Please read the 
   Ras.pas comments about the future merge of rnaph.dll into rasapi32.dll
