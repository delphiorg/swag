TTISearch  (TurboSearch insensitive) is a very fast case insensitive search engine,
based on an article in the German magazine c't (8/97).
 However "Look_at" isn't implemented, because I can't see any sense in Pascal.
The original is in 'C '.